//
//  LMAAppDelegate.h
//  Hello World!
//
//  Created by Bronson, Jennifer C. on 5/7/14.
//  Copyright (c) 2014 Bronson, Jennifer C. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
